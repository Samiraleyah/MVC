package org.launchcode.javawebdevtechjobsmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaWebDevTechjobsMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
