package org.launchcode.javawebdevtechjobsmvc.models;

public class PositionType extends JobField {

    public PositionType(String value) {
        super(value);
    }

}
