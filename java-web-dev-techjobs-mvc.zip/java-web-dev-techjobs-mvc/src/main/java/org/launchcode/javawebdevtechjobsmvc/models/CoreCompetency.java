package org.launchcode.javawebdevtechjobsmvc.models;

public class CoreCompetency extends JobField {

    public CoreCompetency(String value) {
        super(value);
    }

}
