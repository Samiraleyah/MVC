package org.launchcode.javawebdevtechjobsmvc.models;

public class Employer extends JobField {

    public Employer(String value) {
        super(value);
    }

}
