package org.launchcode.javawebdevtechjobsmvc.models;

public class Location extends JobField {

    public Location(String value) {
        super(value);
    }

}
